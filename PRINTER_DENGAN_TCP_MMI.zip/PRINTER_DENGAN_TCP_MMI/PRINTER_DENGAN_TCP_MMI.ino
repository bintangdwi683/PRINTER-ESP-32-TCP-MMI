#include <ArduinoJson.h>
#include <ETH.h>
#include <SPI.h>
#include <WiFi.h>
#include "sMQTTBroker.h"

namespace Config {
constexpr char WIFI_SSID[] = "MMI";
constexpr char WIFI_PASSWORD[] = "MMIindihome";

constexpr uint8_t WIFI_LED_PIN = 2;
constexpr uint8_t PRINTER_RX_PIN = 16;
constexpr uint8_t PRINTER_TX_PIN = 17;
constexpr uint8_t W5500_SCK_PIN = 12;
constexpr uint8_t W5500_MISO_PIN = 13;
constexpr uint8_t W5500_MOSI_PIN = 18;
constexpr uint8_t W5500_CS_PIN = 15;
constexpr uint8_t W5500_IRQ_PIN = 4;
constexpr uint8_t W5500_RESET_PIN = 14;
constexpr int8_t W5500_PHY_ADDRESS = 1;

constexpr uint32_t SERIAL_BAUD_RATE = 115200;
constexpr uint32_t PRINTER_BAUD_RATE = 19200;
constexpr uint16_t MQTT_PORT = 1883;

constexpr size_t PRINT_QUEUE_SIZE = 20;
constexpr size_t JSON_DOCUMENT_SIZE = 1024;
constexpr size_t DEDUPLICATION_CACHE_SIZE = 20;
constexpr double TARGET_TOLERANCE = 50.0;

constexpr unsigned long WIFI_CONNECT_TIMEOUT_MS = 30000;
constexpr unsigned long WIFI_RETRY_INTERVAL_MS = 10000;
constexpr unsigned long WIFI_LED_INTERVAL_MS = 500;
constexpr unsigned long PRINT_RETRY_INTERVAL_MS = 500;
constexpr unsigned long DUPLICATE_WINDOW_MS = 60000;
}  // namespace Config

HardwareSerial printerSerial(2);

    return;
  }

  Serial.print(F("Menghubungkan Wi-Fi"));
  wifiStarted = true;
  WiFi.begin(Config::WIFI_SSID, Config::WIFI_PASSWORD);

  const unsigned long startedAt = millis();
  while (WiFi.status() != WL_CONNECTED &&
         millis() - startedAt < Config::WIFI_CONNECT_TIMEOUT_MS) {
    delay(500);
    Serial.print('.');
  }

  Serial.println();
  if (WiFi.status() == WL_CONNECTED) {
    Serial.print(F("Wi-Fi terhubung. IP ESP32: "));
    Serial.println(WiFi.localIP());
  } else {
    Serial.println(F("Wi-Fi belum terhubung; percobaan dilanjutkan di loop()."));
  }
}

void updateWifiConnection(unsigned long now) {
  // LAN diprioritaskan. Dua interface tidak boleh memakai IP .20 bersamaan.
  if (lanLinkConnected || lanHasIp) {
    if (!lanModeActive) {
      lanModeActive = true;
      WiFi.disconnect(false, false);
      wifiStarted = false;
      Serial.println(F("Wi-Fi standby; komunikasi berpindah ke LAN."));
      broker.restart();
    }
    return;
  }

  if (lanModeActive) {
    lanModeActive = false;
    Serial.println(F("Komunikasi berpindah ke Wi-Fi dengan IP yang sama."));
    broker.restart();
  }

  if (WiFi.status() == WL_CONNECTED) {
    return;
  }

  if (now - lastWifiRetryAt >= Config::WIFI_RETRY_INTERVAL_MS) {
    lastWifiRetryAt = now;
    if (!wifiStarted) {
      Serial.println(F("LAN tidak tersedia; mengaktifkan Wi-Fi cadangan..."));
      wifiStarted = true;
      WiFi.begin(Config::WIFI_SSID, Config::WIFI_PASSWORD);
    } else {
      Serial.println(F("Mencoba menghubungkan ulang Wi-Fi..."));
      WiFi.reconnect();
    }
  }
}

void updateWifiLed(unsigned long now) {
  if (WiFi.status() != WL_CONNECTED && !lanHasIp) {
    wifiLedState = false;
    digitalWrite(Config::WIFI_LED_PIN, LOW);
    return;
  }

  if (now - lastWifiBlinkAt >= Config::WIFI_LED_INTERVAL_MS) {
    lastWifiBlinkAt = now;
    wifiLedState = !wifiLedState;
    digitalWrite(Config::WIFI_LED_PIN, wifiLedState);
  }
}

void processPrintQueue(unsigned long now) {
  if (!queueAvailable() ||
      now - lastPrintCheckAt < Config::PRINT_RETRY_INTERVAL_MS) {
    return;
  }

  lastPrintCheckAt = now;
  const String payload = dequeue();
  printRecipe(payload);
}

void setup() {
  Serial.begin(Config::SERIAL_BAUD_RATE);
  printerSerial.begin(Config::PRINTER_BAUD_RATE, SERIAL_8N1,
                      Config::PRINTER_RX_PIN, Config::PRINTER_TX_PIN);

  pinMode(Config::WIFI_LED_PIN, OUTPUT);
  digitalWrite(Config::WIFI_LED_PIN, LOW);

  WiFi.mode(WIFI_STA);
  if (!WiFi.config(LOCAL_IP, GATEWAY, SUBNET, PRIMARY_DNS, SECONDARY_DNS)) {
    Serial.println(F("Gagal mengatur IP statis."));
  }

  initializeEthernet();
  connectWifi();
  broker.init(Config::MQTT_PORT);
  Serial.println(F("MQTT broker aktif pada Wi-Fi dan LAN, port 1883."));
}

void loop() {
  broker.update();

  const unsigned long now = millis();
  updateWifiConnection(now);
  updateWifiLed(now);
  processPrintQueue(now);

  delay(10);
}
